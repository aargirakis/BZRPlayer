
// only used by Emscripten build
#define  PART_7
#include "cpuemu.c"