
// only used by Emscripten build
#define  PART_1
#include "cpuemu.c"