
// only used by Emscripten build
#define  PART_8
#include "cpuemu.c"