
#define UADE_CONFIG_USER_MODE (0)
#define UADE_CONFIG_BASE_DIR "/usr/local/share/uade2"
#define UADE_CONFIG_UADE_CORE "/usr/local/lib/uade2/uadecore.exe"
#define UADE_CONFIG_HAVE_URANDOM
#define UADE_VERSION "2.13"
#define UADE_HAVE_CYGWIN
