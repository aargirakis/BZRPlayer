#ifndef _CANONICALIZE_FILE_NAME_REP_H_
#define _CANONICALIZE_FILE_NAME_REP_H_

char *canonicalize_file_name(const char *path);

#endif

