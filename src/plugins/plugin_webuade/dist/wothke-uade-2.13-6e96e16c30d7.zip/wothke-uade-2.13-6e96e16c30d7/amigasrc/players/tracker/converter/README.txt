Date: Fri, 19 May 2000 16:50:47 +0200
De: Nicolas Franck <gryzor@club-internet.fr>



Hi there, good ol'(?) Amiga freaks! ;)

Here comes for your pleasure, I hope, the "heart" of Pro-Wizard,
the sourcecodes of all Check'n'Convert routines (53 formats,
minus Protracker's one ;).

Version: 2.20 (the last one, from August '95).

I hope you'll make good use of this, and keep in mind
the loooong nights I spent, understanding, analysing,
and debugging these damn packed formats! :o)

Really, good memories, to me...

And, maybe... I'll come back to this, soon,
as I really want to "revive" my poor A4000,
which is deadly silent for 2 years and a half, now...

W8nC, freaks!

For now, enjoy these sources, and contact me
if you release some tool using them, on another system!

Cheers!

Nicolas "Gryzor" Franck.

gryzor@club-internet.fr
http://perso.club-internet.fr/gryzor/

PS: Greetings to all my pals, friends, and contacts,
from these GOOD OLD AMIGA YEARS! ;)
