#include <stdint.h>
int main(void) { int8_t a = 0; int16_t b = 0; int32_t c = 0; int64_t d = 0; uint8_t e = 0; uint16_t f = 0; uint32_t g = 0; uint64_t h = 0; intptr_t i = 0; return 0; }
