#ifndef _UADE_COMPILER_SUPPORT_H_
#define _UADE_COMPILER_SUPPORT_H_
#define likely(x) (!!(x))
#define unlikely(x) (!!(x))
#endif
