
// only used by Emscripten build
#define  PART_4
#include "cpuemu.c"