 /*
  * UAE - The Un*x Amiga Emulator
  *
  * Target specific stuff, X11 version
  *
  * Copyright 1997 Bernd Schmidt
  */

#define TARGET_NAME "x11"

#define write_log write_log_standard
