
// only used by Emscripten build
#define  PART_6
#include "cpuemu.c"