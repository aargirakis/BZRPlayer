
// only used by Emscripten build
#define PART_5
#include "cpuemu.c"