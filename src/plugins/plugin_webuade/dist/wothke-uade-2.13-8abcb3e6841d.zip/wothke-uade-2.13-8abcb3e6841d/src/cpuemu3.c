
// only used by Emscripten build
#define  PART_3
#include "cpuemu.c"