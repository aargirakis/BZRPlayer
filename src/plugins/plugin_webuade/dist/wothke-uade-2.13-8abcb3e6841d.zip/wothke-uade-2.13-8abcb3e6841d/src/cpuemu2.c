
// only used by Emscripten build
#define  PART_2
#include "cpuemu.c"