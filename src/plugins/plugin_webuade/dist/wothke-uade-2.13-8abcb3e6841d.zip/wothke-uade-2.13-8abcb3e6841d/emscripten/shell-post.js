  return {
	Module: Module,  // expose original Module
  };
})(window.spp_backend_state_UADE);
