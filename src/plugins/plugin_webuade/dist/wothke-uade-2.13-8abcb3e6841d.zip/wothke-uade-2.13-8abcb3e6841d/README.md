# WebUADE

Copyright (C) 2014 Juergen Wothke

This is a JavaScript/WebAudio plugin of UADE (Unix Amiga Delitracker Emulator). This plugin is designed to 
work with my generic WebAudio ScriptProcessor music player (see separate project). 

See 'emscripten' subfolder for more information.

An online demo can be found here: https://www.wothke.ch/webuade/

## LICENSE
See individual files for specific licensing information (most of UADE
uses the terms of the GNU General Public License).

## Credits
Based on UADE version 2.13: http://zakalwe.fi/uade (see AUTHORS file for details)