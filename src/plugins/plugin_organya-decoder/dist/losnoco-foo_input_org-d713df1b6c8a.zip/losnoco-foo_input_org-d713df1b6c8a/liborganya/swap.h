//
//  swap.h
//  org2dat
//
//  Created by Vincent Spader on 6/21/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#include <foobar2000.h>

#define org_btoh_16(x) pfc::byteswap_if_le_t(x)
#define org_btoh_32(x) pfc::byteswap_if_le_t(x)

#define org_ltoh_16(x) x
#define org_ltoh_32(x) x
