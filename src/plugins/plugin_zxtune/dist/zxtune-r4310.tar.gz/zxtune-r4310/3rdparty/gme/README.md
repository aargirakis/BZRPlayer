Game_Music_Emu
==============

Game Music Emu - Multi-purpose console music emulator and player library

Note: I removed Data_Reader.h at some point in the past, so that the library
may be used in the same project as File_Extractor, which also has a repository
on my section of this site.

More documentation may or may not arrive soon.
