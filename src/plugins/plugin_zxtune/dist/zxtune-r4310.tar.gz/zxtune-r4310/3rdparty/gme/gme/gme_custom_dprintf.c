#include "gme_custom_dprintf.h"


gme_custom_dprintf_callback gme_custom_dprintf = 0;
