#ifndef MATHDEFS_H
#define MATHDEFS_H


#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif
#include <math.h>

#ifndef M_PI
#define M_PI  3.14159265358979323846
#endif


#endif
