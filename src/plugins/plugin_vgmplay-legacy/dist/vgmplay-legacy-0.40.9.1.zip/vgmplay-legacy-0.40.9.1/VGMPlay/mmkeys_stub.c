#include "chips/mamedef.h"
#include "mmkeys.h"

UINT8 MultimediaKeyHook_Init(void)
{
    return 0;
}

void MultimediaKeyHook_Deinit(void)
{
    
}

void MultimediaKeyHook_SetCallback(mmkey_cbfunc callbackFunc)
{
    
}
