#include "chips/mamedef.h"

void DBus_ReadWriteDispatch(void)
{

}

void DBus_EmitSignal(UINT8 type)
{

}
