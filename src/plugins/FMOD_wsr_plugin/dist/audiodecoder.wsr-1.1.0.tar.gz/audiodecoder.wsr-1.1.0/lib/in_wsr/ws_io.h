
#ifndef __IO_H__
#define __IO_H__

extern	uint8	*ws_ioRam;

void ws_io_init(void);
void ws_io_reset(void);
void ws_io_done(void);

#endif
