---
name: Bug report
about: Tell us if something is broken. **Please include multiple samples and which game is affected**.
title: "[Bug] "
labels: bug
assignees: ''

---


