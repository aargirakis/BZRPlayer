#ifndef _UBI_MPEG_HELPERS_H
#define _UBI_MPEG_HELPERS_H

#include "../../util/bitstream_msb.h"

int ubimpeg_transform_frame(bitstream_t* is, bitstream_t* os);


#endif
