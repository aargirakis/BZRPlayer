#ifndef __VFS__
#define __VFS__

libstreamfile_t* open_vfs(const char* path);

#endif
