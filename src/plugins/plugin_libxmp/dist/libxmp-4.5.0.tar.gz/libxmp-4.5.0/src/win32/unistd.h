#ifndef LIBXMP_WIN32_UNISTD_H
#define LIBXMP_WIN32_UNISTD_H

#include <io.h>

#endif
