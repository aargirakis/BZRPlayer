======
libxmp 
======
-------------------------------
A tracker module player library
-------------------------------

:Author: Claudio Matsuoka and Hipolito Carraro Jr.
:Date: December 2024
:Version: 4.6
:Manual section: 3
:Manual group: Extended Module Player

.. include:: libxmp.rst
