Libxmp 4.6 API documentation
============================

.. contents:: `Contents`
   :depth: 3

.. raw:: pdf

    PageBreak

.. include:: libxmp.rst
