#ifndef LIBXMP_CORE_PLAYER
#define LIBXMP_CORE_PLAYER
#endif
#include "../loaders/s3m_load.c"
