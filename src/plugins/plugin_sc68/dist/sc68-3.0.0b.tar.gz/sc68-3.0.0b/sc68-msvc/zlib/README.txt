               Precompiled version of Zlib (1.2.8) for sc68


*SYNOPSIS*

  These are pre-compiled version of zlib for linking against different
  runtime-time libraries (RTL).


*FILES*

  zlib-mt.lib (x86 /MT /O2 /Oy- /Z7)
  zlib-mtd.lib (x86 /MTd /Od /Oy- /Z7)


*LINKS*

  zlib <http://www.zlib.net/>
