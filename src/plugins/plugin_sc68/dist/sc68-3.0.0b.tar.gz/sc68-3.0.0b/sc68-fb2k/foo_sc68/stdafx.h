// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#define  _CRT_SECURE_NO_WARNINGS 1

#include "foobar2000.h"
#include "sc68/file68_vfs_def.h"
#include "sc68/file68_vfs.h"
#include "sc68/file68.h"
#include "sc68/sc68.h"
#include "sc68/file68_tag.h"
#include "sc68/file68_msg.h"
#include "sc68/file68_str.h"
#include "input_sc68.h"
