                          sc68 - DirectShow
                                   
                   It is part of the sc68 project.

               (C) COPYRIGHT 1998-2015 Benjamin Gerard


*Synopsis*                                   

  sc68 splitter filter for DirectShow allows to play sc68 files on
  Microsoft Windows platform with with a DirectShow compatible
  player. It includes Microsoft MediaPlayer, MediaPlayer Classic
  (MPC-HC) and many more.

*Files of interest*

  sc68-dshow.sln  - Solution for Microsoft Visual C++ Express 2010
  baseclasses/    - Precompiled Directshow baseclasses and headers
  sc68-splitter/  - sc68 DirectShow splitter project
