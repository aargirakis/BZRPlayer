/* This file exists for documentation purpose only. */
/**
@defgroup  debug68_prg  debug68 program
@ingroup   devtools68

  Create and debug sc68 files.

  @section author AUTHOR

    Copyright (C) 1998-2009 Benjamin Gerard

    This program is free software.

  @section date DATE

    2003

  @section synopsis SYNOPSIS

    debug68 [options ... ] <file>

  @section options OPTIONS

    @arg @b --help                    Display this message and exit.
*/
