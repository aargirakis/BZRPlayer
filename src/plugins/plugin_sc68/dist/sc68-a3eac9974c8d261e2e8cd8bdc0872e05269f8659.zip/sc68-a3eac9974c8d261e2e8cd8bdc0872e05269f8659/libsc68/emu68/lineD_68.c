/* $Id$ */

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "emu68.h"
#include "lines/lineD.c"

