/* line7.c : EMU68 generated code by
 * gen68 Wed May  2 21:50:31 CEST 2007
 * (C) 1998-2007 Benjamin Gerard
 *
 * $Id$
 */

DECL_LINE68(line700)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((0&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line701)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((1&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line702)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((2&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line703)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((3&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line704)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((4&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line705)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((5&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line706)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((6&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line707)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((7&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line708)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((8&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line709)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((9&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line70A)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((10&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line70B)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((11&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line70C)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((12&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line70D)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((13&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line70E)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((14&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line70F)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((15&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line710)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((16&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line711)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((17&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line712)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((18&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line713)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((19&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line714)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((20&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line715)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((21&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line716)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((22&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line717)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((23&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line718)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((24&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line719)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((25&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line71A)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((26&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line71B)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((27&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line71C)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((28&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line71D)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((29&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line71E)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((30&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line71F)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((31&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line720)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((32&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line721)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((33&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line722)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((34&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line723)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((35&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line724)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((36&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line725)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((37&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line726)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((38&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line727)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((39&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line728)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((40&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line729)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((41&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line72A)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((42&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line72B)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((43&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line72C)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((44&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line72D)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((45&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line72E)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((46&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line72F)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((47&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line730)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((48&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line731)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((49&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line732)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((50&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line733)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((51&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line734)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((52&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line735)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((53&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line736)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((54&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line737)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((55&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line738)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((56&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line739)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((57&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line73A)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((58&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line73B)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((59&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line73C)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((60&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line73D)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((61&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line73E)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((62&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

DECL_LINE68(line73F)
{
  /* MOVEQ #xx,Dn */
  int68_t a=(int68_t)(s8) (reg0+((63&31)<<3));
  REG68.d[reg9] = a;
  MOVE(a);
}

