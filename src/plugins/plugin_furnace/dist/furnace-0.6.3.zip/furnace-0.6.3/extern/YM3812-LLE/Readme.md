# YM3812-LLE

Yamaha YM3812 (OPL2) emulator using YM3812 die shot.

Special thanks to Travis Goodspeed for decapping YM3812.

https://twitter.com/travisgoodspeed/status/1652334901230723072

# MODIFICATION DISCLAIMER

this is a modified version of YM3812-LLE which adds functions to allow its usage and per-chan osc.

the original Git commit is 7f0c6537ccd61e9e7dbddb4e4a353e007ea69c50.
