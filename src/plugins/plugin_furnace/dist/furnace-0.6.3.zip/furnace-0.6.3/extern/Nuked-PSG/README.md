# Nuked-PSG
Yamaha YM7101 PSG emulator

# modification disclaimer

this is a modified version of Nuked-PSG which adds support for changing the noise LFSR size and taps.
