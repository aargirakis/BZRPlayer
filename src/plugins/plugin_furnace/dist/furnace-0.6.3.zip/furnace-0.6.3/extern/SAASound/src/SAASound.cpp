// Part of SAASound copyright 1998-2018 Dave Hooper <dave@beermex.com>
//
// SAASound.cpp - dummy function
//
//////////////////////////////////////////////////////////////////////

#include <stdio.h>

// Provide something so the compiler doesn't optimise us out of existance
int SomeFunction ()
{
	return 42;
}
