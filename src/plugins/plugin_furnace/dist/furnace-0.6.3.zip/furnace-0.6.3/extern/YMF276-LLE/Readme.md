# YMF276-LLE

Yamaha YMF276/YM3438 (OPN2) emulator using YM3438 and YMF276 die shots.

Special thanks to John McMaster for decapping YM3438 and org(ogamespec) for decapping YMF276.

https://siliconpr0n.org/map/yamaha/ym3438/

https://drive.google.com/drive/u/0/folders/10IOhV4wf4A6SLQkS-i1wyJnyXH5o8DKn

# MODIFICATION DISCLAIMER

this is a modified version of YMF276-LLE which adds functions for per-chan osc.

the original Git commit is 172b3a40011d0d89528a7fc0d606cc92d94cd033.
