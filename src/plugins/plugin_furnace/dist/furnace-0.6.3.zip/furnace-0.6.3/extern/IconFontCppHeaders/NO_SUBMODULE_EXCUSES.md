# why didn't you just add this as a submodule?

because i don't like main.

yeah, i know, the main part of the code is in main.cpp, but that has history of being ubiquitous.
main branch doesn't.