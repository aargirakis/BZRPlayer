#define FMOPNA_YM2610
#include "fmopna_impl.c"
