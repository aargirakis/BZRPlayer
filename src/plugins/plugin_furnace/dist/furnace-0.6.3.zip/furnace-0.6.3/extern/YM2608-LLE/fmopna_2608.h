#pragma once
#define FMOPNA_YM2608
#include "fmopna_impl.h"
#undef FMOPNA_YM2608

