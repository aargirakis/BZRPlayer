#define FMOPNA_YM2608
#include "fmopna_impl.c"
