# YM2608-LLE

Very low-level Yamaha YM2608B(OPNA), YM2610(OPNB) and YM2612 (OPN2) emulator using die shots.

Special thanks to @ika-musume for decapping YM2608B, John McMaster for decapping YM2610, and HardWareMan for decapping YM2612.

https://siliconpr0n.org/map/yamaha/ym2610/

http://nemesis.hacking-cult.org/MegaDrive/Documentation/YM2612/YM2612_Stiched.jpg
