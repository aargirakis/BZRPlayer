# YMF262-LLE

Yamaha YMF262 (OPL3) emulator using YMF262 die shot.

Special thanks to John McMaster for decapping YMF262.

https://siliconpr0n.org/map/yamaha/ymf262-m/

# MODIFICATION DISCLAIMER

this is a modified version of YMF262-LLE which adds functions to allow its usage and per-chan osc.
it also brings in a small optimization.

the original Git commit is 63406354d05bc860a6762377ddbb9e2609bd6c36.
