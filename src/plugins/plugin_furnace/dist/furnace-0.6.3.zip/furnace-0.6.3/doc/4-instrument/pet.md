# Commodore PET instrument editor

the PET instrument editor consists of these macros:

- **Volume**: volume sequence (on/off).
- **Arpeggio**: pitch sequence.
- **Waveform**: an 8×1 waveform.
- **Pitch**: fine pitch sequence.
