# to-do long term

- CSM macros
- finish auto-clone
- new pattern renderer - performance improvements
- new info header
- unlimited channels and chips
- fix possible issues when moving selection
- fix Metal intro crash
