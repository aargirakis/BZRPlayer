please do not post suggestions, feature requests or non-issue discussions here. go to Discussions if you want to post these instead.
