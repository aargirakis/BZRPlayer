#define XGURU(name) X(plan_guru_ ## name)
#define IODIM X(iodim)
#define MKTENSOR_IODIMS X(mktensor_iodims)
#define GURU_KOSHERP X(guru_kosherp)
