this is a modified version of FFTW for usage in Furnace.

it adds a `WITH_OUR_MALLOC` option to CMakeListst.txt, which was absent in the original release.
