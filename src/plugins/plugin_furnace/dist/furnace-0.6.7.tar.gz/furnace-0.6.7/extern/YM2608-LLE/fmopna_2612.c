#define FMOPNA_YM2612
#include "fmopna_impl.c"
