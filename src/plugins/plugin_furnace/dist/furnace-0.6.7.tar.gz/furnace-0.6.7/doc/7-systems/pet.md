# Commodore PET

a computer from 1977 which was leader on US schools back then. subsequently the Apple II took its throne.

maybe no better than a computer terminal, but somebody discovered a way to update the screen at turbo rate - and eventually its sound "chip" (it was nothing more than an 8-bit shift register) was abused as well.

some of these didn't even have sound...

## effects

- `10xx`: **set waveform.**
  - `xx` is a bitmask.

## info

this chip uses the [PET](../4-instrument/pet.md) instrument editor.
