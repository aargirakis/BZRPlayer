# Yamaha YMZ280B (PCMD8)

8-channel PCM/ADPCM sample-based sound chip designed for use with arcade machines. it lived throughout mid to late 90s.

it has 16-level stereo panning, up to 16-bit PCM and up to 16MB of external PCM data.

## effects

none so far.

## info

this chip uses the [YMZ280B](../4-instrument/ymz280b.md) instrument editor.

## chip config

the following options are available in the Chip Manager window:

- **Clock rate**: sets the rate at which the chip will run.
