# Ricoh RF5C68

YM2612's sidekick - poor man's SNES DSP. 8-channel PCM sample-based synthesizer used in Sega CD, Fujitsu FM Towns and some of Sega's arcade machines. supports up to 64KB of sample data.

## effects

none so far.

## info

this chip uses the [RF5C68](../4-instrument/rf5c68.md) instrument editor.

## chip config

the following options are available in the Chip Manager window:

- **Clock rate**: sets the rate at which the chip will run.
- **Chip type**: changes the chip model.
