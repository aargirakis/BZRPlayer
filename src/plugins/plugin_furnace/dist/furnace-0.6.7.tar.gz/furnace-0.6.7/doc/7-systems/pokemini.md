# Pokémon Mini

the Pokémon Mini is a ridiculously small handheld system from 2001. its single pulse channel has only three volume steps (full, half, and off)... but variable pulse width.

## effects

none.

## info

this chip uses the [Pokémon Mini/QuadTone](../4-instrument/pokemini.md) instrument editor.
