# Commodore VIC instrument editor

the VIC instrument editor consists of these macros:

- **Volume**: volume sequence.
  - note: global! affects entire chip.
- **Arpeggio**: pitch sequence.
- **On/Off**: enable/disable channel output.
- **Waveform**: square wave distortion type sequence.
- **Pitch**: "fine" pitch.
