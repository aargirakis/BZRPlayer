# beeper instrument editor

used in PC Speaker and ZX Spectrum (SFX-like engine).

- **Volume**: on-off volume sequence.
- **Arpeggio**: pitch sequence.
- **Pulse Width**: pulse width sequence.
  - only on ZX Spectrum.
- **Pitch**: fine pitch.
