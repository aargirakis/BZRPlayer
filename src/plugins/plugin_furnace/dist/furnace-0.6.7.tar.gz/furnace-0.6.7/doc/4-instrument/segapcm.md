# SegaPCM instrument editor

the SegaPCM instrument editor contains three tabs: Sample and Macros.

## Sample

for sample settings, see [the Sample instrument editor](sample.md).

## Macros

- **Volume**: volume sequence.
- **Arpeggio**: pitch sequence.
- **Panning (left)**: output level for left channel.
- **Panning (right)**: output level for right channel.
- **Pitch**: fine pitch.
- **Phase Reset**: trigger restart of sample.
