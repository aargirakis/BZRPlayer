# Pokémon Mini/QuadTone instrument editor

used in these two chips/systems. these macros are available:

- **Volume**: volume sequence.
- **Arpeggio**: pitch sequence.
- **Pulse Width**: pulse width sequence.
- **Pitch**: fine pitch.
