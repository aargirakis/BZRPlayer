# VERA instrument editor

VERA instrument editor consists of these macros:

- **Volume**: volume sequence.
- **Arpeggio**: pitch sequence.
- **Duty**: pulse duty cycle sequence.
- **Waveform**: select the waveform used by instrument.
- **Panning**: toggles left/right output.
- **Pitch**: fine pitch.
