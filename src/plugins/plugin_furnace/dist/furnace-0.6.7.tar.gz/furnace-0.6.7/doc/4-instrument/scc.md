# Konami SCC/Bubble System WSG instrument editor

the SCC/Bubble System WSG instrument editor consists of two tabs.

## Wavetable

this allows you to enable and configure the Furnace wavetable synthesizer. see [this page](wavesynth.md) for more information.

be noted that channel 4 and 5 share the same waveform on SCC (non-plus). careful.

## Macros

- **Volume**: volume sequence.
- **Arpeggio**: pitch sequence.
- **Waveform**: specifies wavetable.
- **Pitch**: fine pitch.
