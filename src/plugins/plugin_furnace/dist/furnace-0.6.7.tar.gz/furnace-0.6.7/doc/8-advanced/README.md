# advanced

advanced Furnace features.

as listed in the "Edit" menu:

- [find/replace](find-replace.md)

as listed in the "Window" menu:

- song
  - [song comments](../8-advanced/comments.md)
  - [channels](../8-advanced/channels.md)
  - [chip manager](../8-advanced/chip-manager.md)
  - [pattern manager](../8-advanced/pat-manager.md)
  - [mixer](../8-advanced/mixer.md)
  - [compatibility flags](../8-advanced/compat-flags.md)
- visualizers
  - [oscilloscope](../8-advanced/osc.md)
  - [oscilloscope (per-channel)](../8-advanced/chanosc.md)
  - [oscilloscope (X-Y)](../8-advanced/xyosc.md)
  - volume meter
- tempo
  - [clock](../8-advanced/clock.md)
  - [grooves](../8-advanced/grooves.md)
- debug
  - [log viewer](../8-advanced/log-viewer.md)
  - [register view](../8-advanced/regview.md)
  - [statistics](../8-advanced/stats.md)
  - [memory composition](../8-advanced/memory-composition.md)
- [piano/input pad](../8-advanced/piano.md)

other:

- [command line usage](command-line.md)
