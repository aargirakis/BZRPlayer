# comments

![comments dialog](comments.png)

comments, credits, or any arbitrary text may be entered here. it has no effect on the song.

there is no word wrap; long lines must be broken manually with the Enter/Return key.
