# memory composition

this window displays the memory usage of chips that support memory (e.g. for samples).

![memory composition](memcompo.png)
