The hippel-coso player is in the works to be ported for vasm.
abtest.sh can be used to synthesize hipc songs with the old and the new
hipc player. 'hipc' file is the old player. 'newhipc' file is the new player.

- Heikki Orsila
