#ifndef _UADE_LOGGING_H_
#define _UADE_LOGGING_H_

#include "sysdeps.h"

void uade_logging_flush(void);
void uade_logging_str(const char *s);

#endif
