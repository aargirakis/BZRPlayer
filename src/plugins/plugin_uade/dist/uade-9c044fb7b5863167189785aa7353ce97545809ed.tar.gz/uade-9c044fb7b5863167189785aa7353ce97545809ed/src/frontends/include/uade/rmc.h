#ifndef UADE_RMC_H
#define UADE_RMC_H

#include <uade/uade.h>

#endif
