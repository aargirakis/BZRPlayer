#!/bin/sh
rm -f sd-sound.o audio.o main.o uade.o
