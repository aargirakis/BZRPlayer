#ifndef _SINCTABLE_H_
#define _SINCTABLE_H_

#define SINC_QUEUE_MAX_AGE 2048
extern const int winsinc_integral[5][SINC_QUEUE_MAX_AGE];

#endif
