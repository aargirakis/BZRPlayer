
class ArgumentError(Exception):
    pass
