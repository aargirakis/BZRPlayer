from uade import generate_oscilloscope_view  # noqa: F401
