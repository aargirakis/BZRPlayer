#ifndef _UADE123_PLAYLOOP_H_
#define _UADE123_PLAYLOOP_H_

#include <uade/uade.h>

int play_loop(struct uade_state *state);

#endif
