#ifndef _UADE_CONSTANTS_H_
#define _UADE_CONSTANTS_H_

/* You must not change anything */
#define UADE_DEFAULT_FREQUENCY 44100

#endif
