#include <uae.h>

int main(int argc, char **argv)
{
    return uadecore_main(argc, argv);
}
