#ifndef __VFS__
#define __VFS__

STREAMFILE *open_vfs(const char *path);

#endif
