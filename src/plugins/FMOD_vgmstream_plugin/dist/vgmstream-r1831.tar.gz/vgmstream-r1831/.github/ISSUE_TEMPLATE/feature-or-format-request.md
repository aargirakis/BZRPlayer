---
name: Feature or format request
about: Suggest a feature or a new format that you think vgmstream should play. **Please include multiple samples and which game is affected**.
title: "[Request]"
labels: enhancement
assignees: ''

---

**READ THIS AND THEN DELETE IT. Do not submit issues related to converting audio _TO_ video game music formats. This goes beyond the scope of this project.**
