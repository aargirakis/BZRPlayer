# to-do long term

- finish auto-clone
- new pattern renderer - performance improvements
