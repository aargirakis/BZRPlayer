# demos

demo songs for Furnace.

these demo songs are not under the GPL. all rights are reserved to the original author(s).

# submit demo songs!

contact me or send a pull request if you want your song to be added to this collection. be noted we have three rules:

- Nintendo covers are frowned upon
- big label music covers also are discouraged
- low effort compositions/covers may not be accepted at all.

make sure to put your demo song under the respective category.

tildearrow also accepts demo songs in the .dmf format as well as the .fur format.

thank you for contributing!
