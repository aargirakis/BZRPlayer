# Generic PCM DAC

a sample channel, with freely selectable rate, mono/stereo and bit depth settings.

with it, you can emulate PCM DACs found in Williams arcade boards, Sound Blasters, MSX TurboR, Atari STe, NEC PC-9801-86, among others.

## effects

none yet.

## info

this chip uses the [Generic Sample](../4-instrument/sample.md) instrument editor.
