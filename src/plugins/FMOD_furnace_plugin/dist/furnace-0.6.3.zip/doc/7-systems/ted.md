# MOS Technology TED

also called 7360/8360, TED stands for Text Editing Device. it's both a video and audio chip of Commodore budget computers, like Plus/4 and 16. 

its audio portion is pretty barren - only 2 channels. one can output square wave and other may be either square or noise.
pitch range is limited as well, akin to that of SN76489, and volume control is global.

## effects

none so far.

## info

this chip uses the [TED](../4-instrument/ted.md) instrument editor.
