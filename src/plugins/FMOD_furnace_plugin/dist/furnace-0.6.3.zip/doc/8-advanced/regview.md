# register view

during playback, "Register View" shows the hex data involved with each chip's operation.

![register view dialog](register.png)
