# statistics

the Statistics window shows audio load (CPU used by emulation/playback).

![statistics window](stats.png)
