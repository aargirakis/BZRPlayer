# oscilloscope

the Oscilloscope shows the audio output as a waveform.

![oscilloscope view](osc.png)

right-clicking on the oscilloscope toggles adjustment sliders:
- waveform height (zoom)
- window size (how much of the output to display) in milliseconds.
