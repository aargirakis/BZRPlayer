# advanced

advanced Furnace features.

as listed in the "Edit" menu:

- [find/replace](find-replace.md)

as listed in the "Window" menu:

- [mixer](mixer.md)
- [grooves](grooves.md)
- [channel manager](channels.md)
- [pattern manager](pat-manager.md)
- [chip manager](chip-manager.md)
- [compatibility flags](compat-flags.md)
- [song comments](comments.md)

- [piano](piano.md)
- [oscilloscope](osc.md)
- [oscilloscope (X-Y)](xyosc.md)
- [oscilloscopes (per-channel)](chanosc.md)
- [clock](clock.md)
- [register view](regview.md)
- [log viewer](log-viewer.md)
- [stats](stats.md)

other:

- [command line usage](command-line.md)
