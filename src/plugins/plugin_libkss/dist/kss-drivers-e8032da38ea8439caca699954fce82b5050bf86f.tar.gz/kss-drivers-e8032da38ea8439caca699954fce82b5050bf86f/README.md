# kss-drivers
C header package required for build [libkss](https://github.com/digital-sound-antiques/libkss) library.

These header files are copyrighted materials. 

- mgsdrv.h from mgsdrv.com - MGSDRV (c) Ain./[Gigamix](https://gigamix.hatenablog.com/entry/mgsdrv/)
- kinrou5.h from kinrou5.bin by Keiichi Kuroda
- mpk106.h from mpk.bin by K-KAZ
- mpk103.h from mpk103.bin by K-KAZ
- opx4kss.h from opx4kss.bin by Mikasen (OPLLDriver by Ring is embedded).
