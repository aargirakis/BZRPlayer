# 1.2.1 (2024-08-28)
- Update emu2149 to fix [issue 5](https://github.com/digital-sound-antiques/emu2149/issues/5).

# 1.2.0 (2023-07-16)
- Fix problem where playback rate is slightly faster Thanks to @gcielniak

# 1.1.4 (2022-11-26)
- Update emu2149 to fix [issue 4](https://github.com/digital-sound-antiques/emu2149/issues/4).

# 1.1.3 (2022-11-24)
- Update emu2149 to fix [issue 3](https://github.com/digital-sound-antiques/emu2149/issues/3).

# 1.1.2 (2022-09-21)
- Update emu2413 (again) to fix [this issue](https://github.com/digital-sound-antiques/emu2413/issues/12).

# 1.1.1 (2022-09-19)
- Add non-blocking version of KSS to VGM functionality.
- Update emu2413 to fix [this issue](https://github.com/digital-sound-antiques/emu2413/issues/12).

# 1.1.0 (2022-09-18)
- Add KSS to VGM functionality.
- Fix incorrect prototype definition.

# 1.0.0 (2022-09-14)
- Follow Semantic Versioning
- Update minimum cmake version to 3.0.