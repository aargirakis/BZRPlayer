emu8950
=======

A Y8950/YM3526/YM3812 emulator written in C.