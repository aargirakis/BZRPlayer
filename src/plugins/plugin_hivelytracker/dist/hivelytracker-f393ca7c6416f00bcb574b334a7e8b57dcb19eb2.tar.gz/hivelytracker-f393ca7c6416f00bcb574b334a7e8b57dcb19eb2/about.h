
void about_pre_init( void );
BOOL about_init( void );
void about_shutdown( void );
void about_open( void );
void about_close( void );
void about_toggle( void );
void about_handler( uint32 gotsigs );
