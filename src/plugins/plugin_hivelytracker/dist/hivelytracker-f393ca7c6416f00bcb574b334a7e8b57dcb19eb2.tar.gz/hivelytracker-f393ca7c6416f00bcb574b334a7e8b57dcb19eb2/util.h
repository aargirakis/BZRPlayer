#ifndef __SDL_WRAPPER__
BOOL getLibIFace( struct Library **libbase, TEXT *libname, uint32 version, void *ifaceptr );
#endif
struct Node *allocnode(int32 size);

