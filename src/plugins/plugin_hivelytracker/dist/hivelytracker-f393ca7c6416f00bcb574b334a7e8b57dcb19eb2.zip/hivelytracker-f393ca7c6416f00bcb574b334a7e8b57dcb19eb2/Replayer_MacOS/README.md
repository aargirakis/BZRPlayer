# Mac OS X / macOS command line player

Setup a simple command line project in Xcode.

For Mac OS X < 10.6 you need to link against

* AudioUnit.Framework
* CoreServices.Framework
* CoreFoundation.Framework

For all other Mac OS X / macOS versions use

* AudioToolBox.Framework
* CoreFoundation.Framework

Compile and run.