#ifndef __QSOUND_MAME_H__
#define __QSOUND_MAME_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_QSound_MAME;

#endif	// __QSOUND_MAME_H__
