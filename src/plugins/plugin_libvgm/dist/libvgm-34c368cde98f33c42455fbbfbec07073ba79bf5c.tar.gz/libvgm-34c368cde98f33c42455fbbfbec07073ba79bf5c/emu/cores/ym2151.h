#ifndef __YM2151_H__
#define __YM2151_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_YM2151_MAME;

#endif	// __YM2151_H__
