#ifndef __SN76496_H__
#define __SN76496_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_SN76496_MAME;

#endif	// __SN76496_H__
