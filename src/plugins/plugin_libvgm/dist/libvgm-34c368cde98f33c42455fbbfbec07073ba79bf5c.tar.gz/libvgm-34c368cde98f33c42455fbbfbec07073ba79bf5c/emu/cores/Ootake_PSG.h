#ifndef __OOTAKE_PSG_H__
#define __OOTAKE_PSG_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_C6280_Ootake;

#endif	// __OOTAKE_PSG_H__
