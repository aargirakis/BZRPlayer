#ifndef __YMZ280B_H__
#define __YMZ280B_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_YMZ280B[];

#endif	// __YMZ280B_H__
