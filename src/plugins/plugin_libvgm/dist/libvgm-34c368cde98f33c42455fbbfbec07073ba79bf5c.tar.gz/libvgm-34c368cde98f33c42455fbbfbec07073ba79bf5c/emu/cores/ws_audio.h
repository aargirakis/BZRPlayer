#ifndef __WS_AUDIO_H__
#define __WS_AUDIO_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_WSwan[];

#endif	// __WS_AUDIO_H__
