#ifndef __SN76489_H__
#define __SN76489_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_SN76489_Maxim;

#endif	// __SN76489_H__
