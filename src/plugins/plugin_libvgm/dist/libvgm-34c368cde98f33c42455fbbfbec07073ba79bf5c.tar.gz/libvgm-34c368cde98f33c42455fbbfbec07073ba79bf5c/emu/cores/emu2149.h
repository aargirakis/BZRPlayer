#ifndef __EMU2149_H__
#define __EMU2149_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_YM2149_Emu;

#endif	// __EMU2149_H__
