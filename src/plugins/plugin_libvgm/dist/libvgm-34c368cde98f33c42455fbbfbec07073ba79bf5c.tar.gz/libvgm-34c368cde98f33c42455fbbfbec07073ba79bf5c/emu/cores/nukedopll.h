#ifndef __NUKEDOPLL_H__
#define __NUKEDOPLL_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_YM2413_Nuked;

#endif	// __NUKEDOPLL_H__
