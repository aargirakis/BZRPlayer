#ifndef __K053260_H__
#define __K053260_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_K053260[];

#endif	// __K053260_H__
