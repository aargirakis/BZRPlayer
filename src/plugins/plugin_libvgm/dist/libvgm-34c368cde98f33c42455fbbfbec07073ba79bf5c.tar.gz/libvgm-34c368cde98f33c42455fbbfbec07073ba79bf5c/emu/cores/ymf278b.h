#ifndef __YMF278B_H__
#define __YMF278B_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_YMF278B[];

#endif	// __YMF278B_H__
