#define OPLTYPE_IS_OPL3
#define INCLUDE_FROM_ADLIBEMU_OPL_C
#include "adlibemu.h"
#include "adlibemu_opl_inc.c"
