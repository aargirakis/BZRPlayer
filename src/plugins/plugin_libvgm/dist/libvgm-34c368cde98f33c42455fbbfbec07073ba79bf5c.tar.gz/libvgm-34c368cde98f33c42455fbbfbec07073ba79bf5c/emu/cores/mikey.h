#ifndef __MIKEY_H__
#define __MIKEY_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_Mikey[];

#endif	// __MIKEY_H__

