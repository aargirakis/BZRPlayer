#ifndef __OKIM6295_H__
#define __OKIM6295_H__

#include "../EmuStructs.h"

// cfg.flags: pin 7 state, controls clock divider - 0 = clk/165, 1 = clk/132

extern const DEV_DEF* devDefList_OKIM6295[];

#endif	// __OKIM6295_H__
