#ifndef __ES5503_H__
#define __ES5503_H__

#include "../EmuStructs.h"

// cfg.flags: output channels (1..16, downmixed to stereo)

extern const DEV_DEF* devDefList_ES5503[];

#endif	// __ES5503_H__
