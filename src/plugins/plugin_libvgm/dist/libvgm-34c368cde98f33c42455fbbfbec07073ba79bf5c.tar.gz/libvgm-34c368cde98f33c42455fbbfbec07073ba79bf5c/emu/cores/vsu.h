#ifndef __VB_VSU_H__
#define __VB_VSU_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_VBoyVSU[];

#endif	// __VB_VSU_H__
