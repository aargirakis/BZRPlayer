#include <stddef.h>

#include "../../stdtype.h"
#include "../EmuStructs.h"
#include "es5506.h"

const DEV_DEF* devDefList_ES5506[] =
{
	NULL
};
