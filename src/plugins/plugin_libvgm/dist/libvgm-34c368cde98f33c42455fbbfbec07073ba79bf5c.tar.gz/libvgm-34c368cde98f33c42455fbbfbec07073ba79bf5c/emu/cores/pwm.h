#ifndef __PWM_H__
#define __PWM_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_32X_PWM[];

#endif	// __PWM_H__
