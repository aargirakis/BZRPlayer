#ifndef __POKEY_H__
#define __POKEY_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_Pokey[];

#endif	// __POKEY_H__
