#ifndef __EMU2413_H__
#define __EMU2413_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_YM2413_Emu;

#endif	// __EMU2413_H__
