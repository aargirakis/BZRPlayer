#ifndef __YMF271_H__
#define __YMF271_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_YMF271[];

#endif	// __YMF271_H__
