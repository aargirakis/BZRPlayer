#ifndef __MULTIPCM_H__
#define __MULTIPCM_H__

#include "../EmuStructs.h"

extern const DEV_DEF* devDefList_YMW258[];

#endif	// __MULTIPCM_H__
