cmake \
  --build ${PATH_FIXER_CHECKOUT_PATH}/build \
  --config ${INPUTS_BUILD_TYPE} \
  --parallel 2
