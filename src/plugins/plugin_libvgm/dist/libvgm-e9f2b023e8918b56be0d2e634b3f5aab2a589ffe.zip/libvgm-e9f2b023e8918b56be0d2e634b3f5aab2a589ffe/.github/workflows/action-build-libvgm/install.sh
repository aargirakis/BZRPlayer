cmake \
  --install ${PATH_FIXER_CHECKOUT_PATH}/build \
  --config ${INPUTS_BUILD_TYPE}
