#ifndef __QSOUND_CTR_H__
#define __QSOUND_CTR_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_QSound_ctr;

#endif	// __QSOUND_CTR_H__
