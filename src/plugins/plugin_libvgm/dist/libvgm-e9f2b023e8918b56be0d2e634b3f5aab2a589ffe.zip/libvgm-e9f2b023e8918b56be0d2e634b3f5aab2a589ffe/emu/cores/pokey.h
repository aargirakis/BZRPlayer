#ifndef __POKEY_H__
#define __POKEY_H__

#include "../EmuStructs.h"

extern const DEV_DECL sndDev_Pokey;

#endif	// __POKEY_H__
