#ifndef __C219_H__
#define __C219_H__

#include "../EmuStructs.h"

extern const DEV_DECL sndDev_C219;

#endif	// __C219_H__
