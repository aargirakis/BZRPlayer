#ifndef __K007232_H__
#define __K007232_H__

#include "../EmuStructs.h"

extern const DEV_DECL sndDev_K007232;

#endif  // __K007232_H__