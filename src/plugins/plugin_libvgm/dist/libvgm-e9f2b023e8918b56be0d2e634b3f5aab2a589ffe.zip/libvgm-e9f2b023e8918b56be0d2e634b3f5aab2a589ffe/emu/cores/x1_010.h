#ifndef __X1_010_H__
#define __X1_010_H__

#include "../EmuStructs.h"

extern const DEV_DECL sndDev_X1_010;

#endif	// __X1_010_H__
