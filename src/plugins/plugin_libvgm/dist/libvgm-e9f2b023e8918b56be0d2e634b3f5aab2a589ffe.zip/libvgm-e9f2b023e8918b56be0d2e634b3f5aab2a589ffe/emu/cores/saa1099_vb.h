#ifndef __SAA1099_VB_H__
#define __SAA1099_VB_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_SAA1099_VB;

#endif	// __SAA1099_VB_H__
