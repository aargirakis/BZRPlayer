#ifndef __YMF271_H__
#define __YMF271_H__

#include "../EmuStructs.h"

extern const DEV_DECL sndDev_YMF271;

#endif	// __YMF271_H__
