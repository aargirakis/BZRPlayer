#define OPLTYPE_IS_OPL2
#define INCLUDE_FROM_ADLIBEMU_OPL_C
#include "adlibemu.h"
#include "adlibemu_opl_inc.c"
