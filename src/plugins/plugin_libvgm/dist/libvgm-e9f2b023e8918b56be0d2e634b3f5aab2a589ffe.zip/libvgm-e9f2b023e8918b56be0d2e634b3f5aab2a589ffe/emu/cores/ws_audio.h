#ifndef __WS_AUDIO_H__
#define __WS_AUDIO_H__

#include "../EmuStructs.h"

extern const DEV_DECL sndDev_WSwan;

#endif	// __WS_AUDIO_H__
