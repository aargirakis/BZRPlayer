#ifndef __SCD_PCM_H__
#define __SCD_PCM_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_RF5C68_Gens;

#endif	// __SCD_PCM_H__
