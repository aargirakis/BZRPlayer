#ifndef __VB_VSU_H__
#define __VB_VSU_H__

#include "../EmuStructs.h"


#define OPT_VST_WRAM_WRT_WHILE_ON	0x0001	// allow writes to waveRAM while sound is on (buggy emulation)


extern const DEV_DECL sndDev_VBoyVSU;

#endif	// __VB_VSU_H__
