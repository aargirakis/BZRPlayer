#ifndef __MIKEY_H__
#define __MIKEY_H__

#include "../EmuStructs.h"

extern const DEV_DECL sndDev_Mikey;

#endif	// __MIKEY_H__

