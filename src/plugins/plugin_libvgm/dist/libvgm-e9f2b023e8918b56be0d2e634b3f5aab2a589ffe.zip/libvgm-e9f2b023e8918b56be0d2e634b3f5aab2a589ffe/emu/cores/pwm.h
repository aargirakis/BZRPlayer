#ifndef __PWM_H__
#define __PWM_H__

#include "../EmuStructs.h"

extern const DEV_DECL sndDev_32X_PWM;

#endif	// __PWM_H__
