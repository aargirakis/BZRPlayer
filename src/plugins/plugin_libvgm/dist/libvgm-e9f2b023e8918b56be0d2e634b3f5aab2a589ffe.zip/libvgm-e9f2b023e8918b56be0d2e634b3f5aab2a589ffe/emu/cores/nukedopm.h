#ifndef __NUKEDOPM_H__
#define __NUKEDOPM_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_YM2151_Nuked;

#endif	// __NUKEDOPM_H__
