#ifndef __YMF278B_H__
#define __YMF278B_H__

#include "../EmuStructs.h"

extern const DEV_DECL sndDev_YMF278B;

#endif	// __YMF278B_H__
