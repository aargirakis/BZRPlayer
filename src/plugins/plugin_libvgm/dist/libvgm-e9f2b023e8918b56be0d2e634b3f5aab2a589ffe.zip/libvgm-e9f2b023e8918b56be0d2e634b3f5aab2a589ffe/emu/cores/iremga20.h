#ifndef __IREMGA20_H__
#define __IREMGA20_H__

#include "../EmuStructs.h"

#define OPT_GA20_INTERPOLATE	0x01	// enable linear interpolation for samples (default: disabled)

extern const DEV_DECL sndDev_GA20;

#endif	// __IREMGA20_H__
