#ifndef __C6280_MAME_H__
#define __C6280_MAME_H__

#include "../EmuStructs.h"

extern DEV_DEF devDef_C6280_MAME;

#endif	// __C6280_MAME_H__
