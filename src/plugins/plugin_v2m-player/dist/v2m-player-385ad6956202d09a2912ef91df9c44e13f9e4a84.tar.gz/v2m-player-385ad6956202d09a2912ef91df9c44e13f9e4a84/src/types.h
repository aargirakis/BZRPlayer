#pragma once

#define sTRUE             1
#define sFALSE            0
