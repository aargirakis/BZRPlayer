/*
* This file adapts "Ken's SND/SM/KSM/KDM plugin (x86)" (see http://advsys.net/ken/) to the interface
* expected by my generic JavaScript player.
*
* This player plays:
*  Ken's 4-note music (*.SND)
*  Ken's CT-640 music (*.SM)
*  Ken'S adlib Music (*.KSM)
*  Ken's Digitial Music (*.KDM)
*
*
* See the included license file "BUILDLIC.TXT" for license info.
*
* "webKen" Copyright (c) 2023 Juergen Wothke
* "Ken's SND/SM/KSM/KDM plugin (x86)" Copyright (c) Ken Silverman
*/

#include <emscripten.h>

#include <stdio.h>


#include <exception>
#include <iostream>
#include <fstream>
#include <sys/stat.h>	// fstat


// just something to see in the binary
const char *info = "\"Ken's SND/SM/KSM/KDM plugin\" Copyright (c) 1993-1997 Ken Silverman\nKen Silverman's official web site: \"http://www.advsys.net/ken\"\nSee the included license file \"BUILDLIC.TXT\" for license info\n\"webKen\" Copyright (c) 2023 Juergen Wothke";


// ---- interfacing with Ken's code

	//SMSND variables & code
extern "C" long smsndsamplerate, smsndnumspeakers, smsndbytespersample;
extern "C" long smsndload (char *);
extern "C" void smsndseek (long);
extern "C" void smsndmusicon ();
extern "C" void smsndmusicoff ();
extern "C" long smsndrendersound (void *, long);

	//KSM variables & code
extern "C" unsigned int speed;
extern "C" long ksmsamplerate, ksmnumspeakers, ksmbytespersample;
extern "C" long ksmload (char *);
extern "C" void ksmseek (long);
extern "C" void ksmmusicon ();
extern "C" void ksmmusicoff ();
extern "C" long ksmrendersound (void *, long);

	//KDM variables & code
extern "C" int kdmsamplerate;
extern "C" int kdmload (char *);
extern "C" void kdmseek (long);
extern "C" void kdmmusicon ();
extern "C" void kdmmusicoff ();
extern "C" long kdmrendersound (char *dasnd, int numbytes);


// ---- unused: interfacing with the JavaScript side (ems_request_file could be used for a load on demand..)

extern "C" int ems_request_file(const char *filename);	// see callback.js

#define SAMPLE_BUF_SIZE	576


namespace ken {

	class Adapter {
	private:
		int16_t _sampleBuffer[SAMPLE_BUF_SIZE*2*2];
		long _sampleBufferLen;

		long _songlengms;
		long _songtype;	  //0 for SMSND, 1 for KSM, 2 for KDM
		long _bytespersample, _numspeakers, _xbits;

		uint32_t _sampleRate;

		// current song status
		long long _samplesPlayed;	// need 64 bit (to avoid overflow)

	public:
		Adapter()
		{
			_songlengms = -1000;
			_songtype = 0;
			_bytespersample = 2;
			_numspeakers = 2;

		}

		void teardown()
		{
		}

		void musicOff()
		{
			switch (_songtype) {
				case 0: smsndmusicoff(); break;
				case 1: ksmmusicoff(); break;
				case 2: kdmmusicoff(); break;
			}
		}

		int init(char *songmodule, void *inBuffer, uint32_t inBufSize, uint32_t sampleRate, uint32_t audioBufSize, uint32_t scopesEnabled)
		{
			// fixme: audioBufSize, scopesEnabled support not implemented

			_songtype = -1;
			int i = strlen(songmodule);
			if ((!strcmp(&songmodule[i-3],".SM")) || (!strcmp(&songmodule[i-3],".sm"))) _songtype = 0;
			if ((!strcmp(&songmodule[i-4],".SND")) || (!strcmp(&songmodule[i-4],".snd"))) _songtype = 0;
			if ((!strcmp(&songmodule[i-4],".KSM")) || (!strcmp(&songmodule[i-4],".ksm"))) _songtype = 1;
			if ((!strcmp(&songmodule[i-4],".KDM")) || (!strcmp(&songmodule[i-4],".kdm"))) _songtype = 2;
			if (_songtype == -1) return(1);

			_xbits = _numspeakers + _bytespersample-2;

			_sampleRate = sampleRate;

			// initialization code... at this point the browser has already loaded the initial
			// music file and only the KDM player will try to load an addditional "waves.kwv"
			// file. No point in adding asnchronous file loading capabilities for this scenario -
			// just preload the "waves.kwv" file and everything can be kept as is.

			switch(_songtype)
			{
				case 0:
					//speed = 240;
					smsndsamplerate = _sampleRate;
					smsndnumspeakers = _numspeakers;
					smsndbytespersample = _bytespersample;
					if ((_songlengms = smsndload(songmodule)) <= 0) return(1);
					smsndmusicon();

					break;
				case 1:
					speed = 240;
					ksmsamplerate = _sampleRate;
					ksmnumspeakers = _numspeakers;
					ksmbytespersample = _bytespersample;
					if ((_songlengms = ksmload(songmodule)) <= 0) return(1);
					ksmmusicon();
					break;
				case 2:
					kdmsamplerate = _sampleRate;
					if ((_songlengms = kdmload(songmodule)) <= 0) {
						fprintf(stderr, "error: kdmload failed\n");
						return(1);
					}
					kdmmusicon();
					break;
			}

			memset(_sampleBuffer,0,sizeof(_sampleBuffer));

			_sampleBufferLen = SAMPLE_BUF_SIZE;
			if (_songtype == 2) // HACK: _sampleBufferLen for kdm MUST be multiple of _sampleRate/120
				_sampleBufferLen -= (_sampleBufferLen % (_sampleRate / 120)); //In (44100,2,2): 2304->2202
			_sampleBufferLen <<= _xbits;

			_samplesPlayed = 0;

			seekPosition(0);

			return 0;
		}

		int genSamples()
		{
			if (getCurrentPosition() < getMaxPosition())
			{
				int loopcnt = 0;
				switch (_songtype)
				{	// 2nd param "numberofbytestoprocess"!? NOT SAMPLES!
					case 0: loopcnt = smsndrendersound((void *)_sampleBuffer,_sampleBufferLen); break;
					case 1: loopcnt = ksmrendersound((void *)_sampleBuffer,_sampleBufferLen); break;
					case 2: loopcnt = kdmrendersound((char *)_sampleBuffer,_sampleBufferLen); break;
				}

				if (loopcnt >= 1)
				{
					return 1;		// end song
				}
				_samplesPlayed += (_sampleBufferLen>>_xbits) ;	// in ticks (irrelevant how many channels are playing)

				return 0;
			}
			return 1; // end song
		}

		int getSampleRate()
		{
			return _sampleRate;
		}

		int setSubsong(int subsong)
		{
			return 0; // should be irrelevant here
		}

		int16_t* getAudioBuffer()
		{
			return _sampleBuffer;
		}

		long getAudioBufferLength()
		{
			return _sampleBufferLen>>_xbits;
		}

		int getCurrentPosition() 	// in ms
		{
			return 1000 * _samplesPlayed / _sampleRate;
		}

		int getMaxPosition() 	// in ms
		{
			return _songlengms;
		}

		void seekPosition(int ms)
		{
			if (ms != -1) {
				switch (_songtype) {
					case 0: smsndseek(ms); break;
					case 1: ksmseek(ms); break;
					case 2: kdmseek(ms); break;
				}
				_samplesPlayed = _sampleRate * ms/ 1000;
			}
		}
	};
};

ken::Adapter _adapter;



// old style EMSCRIPTEN C function export to JavaScript.
// todo: code might be cleaned up using EMSCRIPTEN's "new" Embind feature:
// https://emscripten.org/docs/porting/connecting_cpp_and_javascript/embind.html
#define EMBIND(retType, func)  \
	extern "C" retType func __attribute__((noinline)); \
	extern "C" retType EMSCRIPTEN_KEEPALIVE func

EMBIND(void, emu_teardown()) { _adapter.teardown(); }
EMBIND(int, emu_load_file(char *filename, void *inBuffer, uint32_t inBufSize, uint32_t sampleRate, uint32_t audioBufSize, uint32_t scopesEnabled)) {
	return _adapter.init(filename, inBuffer, inBufSize, sampleRate, audioBufSize, scopesEnabled); }
EMBIND(int, emu_get_sample_rate()) { return _adapter.getSampleRate(); }
EMBIND(int, emu_set_subsong(int subsong)) { return _adapter.setSubsong(subsong); }
EMBIND(char*, emu_get_audio_buffer()) { return (char*)_adapter.getAudioBuffer(); }
EMBIND(long, emu_get_audio_buffer_length()){ return _adapter.getAudioBufferLength(); }
EMBIND(int, emu_get_current_position()) { return _adapter.getCurrentPosition(); }
EMBIND(int, emu_get_max_position()) { return _adapter.getMaxPosition(); }
EMBIND(int, emu_compute_audio_samples()) { return _adapter.genSamples(); }
EMBIND(void, emu_seek_position(int pos)) { _adapter.seekPosition(pos); }

