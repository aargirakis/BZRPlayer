let songs = [
		"AWESONG.SM",
		"COOLSONG.SM",
		"GOODSONG.SM",
		"MINUET.SM",
		"NEWSONG.SM",
		"NOTEGAIN.SM",
		"RADSONG.SM",
		"RETOUR.SM",
		"SM.SM",
		"SNAUSONG.SM",
		"SONATINA.SM",

		"NOTEGAIN.SND",
		"NEWSONG.SND",
		"MARIO.SND",
		"GAME.SND",
		"GAMEOVER.SND",
		"INTRO.SND",
		"CHART.SND",
		"ENTER.SND",

		"BLASTONG.KDM",
		"DRIFSNG2.KDM",
		"FID0307.KDM",
		"fid0527.kdm",
		"FID0830B.KDM",
		"FLYSONG.KDM",
		"JOYSONG.KDM",
		"KDMSONG.KDM",
		"KLABSONG.KDM",
		"MU40PROJ.KDM",
		"NASTPROJ.KDM",
		"PREPSONG.KDM",
		"QUIKSONG.KDM",

		"XLSONG.KSM",
		"WALSNG04.KSM",
		"STARSONG.KSM",
		"SADDYSNG.KSM",
		"REOSONG.KSM",
		"POWSONG.KSM",
		"NOTEGAIN.KSM",
		"MAXOSONG.KSM",
		"LIVESONG.KSM",
		"JAZZSONG.KSM",
		"EVILTUNE.KSM",
		"DRUMSONG.KSM",
		"DRUMSNG2.KSM",
		"BESTSONG.KSM",
		"ANDYSONG.KSM",
	];

class KenDisplayAccessor extends DisplayAccessor {
	constructor(doGetSongInfo)
	{
		super(doGetSongInfo);
	}

	getDisplayTitle()		{ return "webKen";}
	getDisplaySubtitle()	{ return "Ken's Music";}
	getDisplayLine1() 		{ return this.getSongInfo().title;}
	getDisplayLine2() { return ""; }
	getDisplayLine3() { return ""; }
};


class Main {
	constructor()
	{
		this._backend;
		this._playerWidget;
		this._songDisplay;
	}

	_doOnUpdate()
	{
		if (typeof this._lastId != 'undefined')
		{
			window.cancelAnimationFrame(this._lastId);	// prevent duplicate chains
		}
		this._animate();

		this._songDisplay.redrawSongInfo();
	}

	_animate()
	{
		this._songDisplay.redrawSpectrum();
		this._playerWidget.animate()

		this._lastId = window.requestAnimationFrame(this._animate.bind(this));
	}

	_doOnTrackEnd()
	{
		this._playerWidget.playNextSong();
	}

	_playSongIdx(i)
	{
		this._playerWidget.playSongIdx(i);
	}

	_addSpacer()
	{
		let $div = $("<div>", {
			class: "column",
		  }).appendTo('#playlist');
		$('<div>').html('&nbsp;').appendTo($div);
	}

	_renderDirectLinks(songs)
	{
		for (let i= 0; i < songs.length; i++) {

		  let $div = $("<div>", {
			class: "column",
		  }).appendTo('#playlist');

			$('<a>',{
				text: songs[i],
				title: songs[i],
				href: '#',
				click: function() { this._playSongIdx( i ); return false;}.bind(this, i)
			}).appendTo($div);
		}
		this._addSpacer();
		this._addSpacer();
		this._addSpacer();
	}

	run()
	{
		this._renderDirectLinks(songs);

		let preloadFiles =  [
			"music/insts/WAVES.KWV",	// only needed fpr KDM files (must be upper case!)
			// inst.dat no longer needed for KSM (since inlined)
		];

		// note: with WASM this may not be immediately ready
		this._backend = new KenBackendAdapter(true);
		this._backend.setProcessorBufSize(2048);

		ScriptNodePlayer.initialize(this._backend, this._doOnTrackEnd.bind(this), preloadFiles, true, undefined)
		.then((msg) => {

			let makeOptionsFromUrl = function(someSong) {
					let options = {};

					let arr = someSong.split(";");
					options.timeout = arr.length > 1 ? parseInt(arr[1]) : -1;

					return ["music/" + arr[0], options];
				};

			this._playerWidget = new BasicControls("controls", songs, makeOptionsFromUrl, this._doOnUpdate.bind(this), false, true);

			this._songDisplay = new SongDisplay(new KenDisplayAccessor((function(){return this._playerWidget.getSongInfo();}.bind(this) )),
								[0xc93b3e, 0xe2e237, 0x359061, 0x6c3cff], 1, 0.1);

			this._playerWidget.playNextSong();
		});
	}
}