/*
 ken_adapter.js: Adapts IN_KEN backend to generic WebAudio/ScriptProcessor player.


 version 1.1

 	Copyright (C) 2023 Juergen Wothke

 LICENSE

	See the included license file "BUILDLIC.TXT" for license info.
*/

class KenFileMapper extends SimpleFileMapper {
	constructor(module)
	{
		super(module);
	}

	registerFileData(pathFilenameArray, data)
	{
		// WAVES.KWV is the only add-on file needed and it is easier to just
		// preload that from some fixed location

		if(pathFilenameArray[1].indexOf("WAVES.KWV") >= 0)
		{
			pathFilenameArray[0] = "";
			pathFilenameArray[1] = "WAVES.KWV";
		}
		return super.registerFileData(pathFilenameArray, data);
	}
};


class KenBackendAdapter extends EmsHEAP16BackendAdapter {
	constructor()
	{
		super(backend_KEN.Module, 2, new KenFileMapper(backend_KEN.Module));

		this.ensureReadyNotification();
	}

	loadMusicData(sampleRate, path, filename, data, options)
	{
		filename = this._getFilename(path, filename);

		let ret = this._loadMusicDataBuffer(filename, data, ScriptNodePlayer.getWebAudioSampleRate(), -999, false);

		if (ret == 0)
		{
			this._setupOutputResampling(sampleRate);
		}
		return ret;
	}

	getSongInfoMeta()
	{
		return {
			title: String
		};
	}

	updateSongInfo(filename)
	{
		let result = this._songInfo;
		result.title = filename.replace(/^.*[\\\/]/, '');
	}
};
