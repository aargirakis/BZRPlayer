The songs in this folder were created by Ken Silverman and they can be downloaded as separate packages
from his download page http://advsys.net/ken/download.htm  (see KDMSONGS.ZIP, KSMSONGS.ZIP & OLDSONGS.ZIP ).

The copyright of the songs is entirely his and I hope he doesn't mind that I copied them here for 
convenience.

