# webKen

This is a JavaScript/WebAudio port of "Ken Silverman's 'in_ken' Winamp 2.x plug-in". This port is 
designed to work as a plugin for my generic WebAudio ScriptProcessor music player (see separate project). 

It allows to play all of Ken's music formats. (which can be found on his download page:
http://advsys.net/ken/download.htm , etc)

A live demo of this program can be found here: http://www.wothke.ch/webKen/


## Credits

The project is based on Ken Silverman's original Winamp sources found here: http://advsys.net/ken/util/in_ken_src.zip


## Project

It includes a somewhat patched/stripped down version of in_ken (see original sources in emscripten/docs folder). The 
main changes have to do with fixing "unaligned memory access" issues and replacing code that was originally written 
in x86 ASM. The code patches have been usually marked with an "EMSCRIPTEN" comment (or respective #ifdef).

All the "Web" specific additions (i.e. the whole point of this project) are contained in the "emscripten" subfolder. The main 
interface between the JavaScript/WebAudio world and the original C code is the Adapter.cpp file. 


## Howto build

You'll need Emscripten (http://kripken.github.io/emscripten-site/docs/getting_started/downloads.html). The make script 
is designed for use of emscripten version 1.37.29 (unless you want to create WebAssembly output, older versions might 
also still work) and the last version I used was 1.38.13.

The below instructions assume that a command prompt has been opened within the "webSNSF/emscripten" sub-folder, 
and that the Emscripten environment vars have been previously set (run EMSCRIPTEN's emsdk_env.bat).

The Web version is then built using the makeEmscripten.bat that can be found in this folder. The 
script will compile directly into the "emscripten/htdocs" example web folder, were it will create 
the backend_ken.js library. (To create a clean-build you have to delete any previously built libs in the 
'built' sub-folder! (a trade-off of not using a proper make tool). The content of the "htdocs" can be tested 
by first copying it into some document folder of a web server. 


## Known limitations

This port was hacked together quicky and no time has been invested into rigorous testing / code review. It is
likely I introduced bugs that I didn't notice while playing the example songs.

The copy/paste reuse in the interface parts may have left unnecessary ballast (i.e. unused code) in the 
implementaion: Other players rely on asynchronous load-on-demand (e.g. for additional instrument files used by the 
main song file) but since only 2 such files seem to exist in this context these files are just always loaded in 
advance - saving the trouble to modify existing APIs to allow for the additional "async file load still in progress"
scenario. 


## Depencencies

The current version requires version >=1.2.1 of my https://bitbucket.org/wothke/webaudio-player/



## License

Ken agreed that I use the same license here that he has used for his "Build Engine & Tools" project.
The details can be found in the correspondingly adapted BUILDLIC.TXT file. The license conditions 
apply to Ken's respective code as well as to my "web port" code additions.


"Ken's SND/SM/KSM/KDM plugin" Copyright (c) Ken Silverman
"webKen" Copyright (c) 2023 Juergen Wothke


