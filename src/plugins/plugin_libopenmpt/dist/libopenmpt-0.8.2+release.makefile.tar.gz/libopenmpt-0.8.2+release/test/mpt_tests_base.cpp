
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/base/tests/tests_base_arithmetic_shift.hpp"
#include "mpt/base/tests/tests_base_bit.hpp"
#include "mpt/base/tests/tests_base_math.hpp"
#include "mpt/base/tests/tests_base_numeric.hpp"
#include "mpt/base/tests/tests_base_saturate_cast.hpp"
#include "mpt/base/tests/tests_base_saturate_round.hpp"
#include "mpt/base/tests/tests_base_wrapping_divide.hpp"

#endif
