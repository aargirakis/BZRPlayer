
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/binary/tests/tests_binary.hpp"

#endif
