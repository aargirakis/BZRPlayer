
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/random/tests/tests_random.hpp"

#endif
