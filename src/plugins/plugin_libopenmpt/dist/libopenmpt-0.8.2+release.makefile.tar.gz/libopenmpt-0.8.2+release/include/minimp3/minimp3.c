/* #define MINIMP3_NO_SIMD */
#define MINIMP3_IMPLEMENTATION
#include "minimp3.h"
