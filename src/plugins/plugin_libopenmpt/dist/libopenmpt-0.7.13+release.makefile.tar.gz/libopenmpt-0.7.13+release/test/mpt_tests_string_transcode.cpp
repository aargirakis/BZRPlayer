
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/string_transcode/tests/tests_string_transcode.hpp"

#endif
