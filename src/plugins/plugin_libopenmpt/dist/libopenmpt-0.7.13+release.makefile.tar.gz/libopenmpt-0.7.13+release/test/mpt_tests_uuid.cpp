
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/uuid/tests/tests_uuid.hpp"

#endif
