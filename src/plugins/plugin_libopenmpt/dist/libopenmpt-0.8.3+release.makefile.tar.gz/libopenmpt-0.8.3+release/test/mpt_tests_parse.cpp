
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/parse/tests/tests_parse.hpp"

#endif
