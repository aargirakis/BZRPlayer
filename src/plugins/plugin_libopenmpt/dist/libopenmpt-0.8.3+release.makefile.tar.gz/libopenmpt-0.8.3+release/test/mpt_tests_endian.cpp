
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/endian/tests/tests_endian_floatingpoint.hpp"
#include "mpt/endian/tests/tests_endian_int24.hpp"
#include "mpt/endian/tests/tests_endian_integer.hpp"

#endif
