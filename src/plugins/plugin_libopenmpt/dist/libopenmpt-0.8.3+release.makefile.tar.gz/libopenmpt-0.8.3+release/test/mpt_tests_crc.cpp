
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/crc/tests/tests_crc.hpp"

#endif
