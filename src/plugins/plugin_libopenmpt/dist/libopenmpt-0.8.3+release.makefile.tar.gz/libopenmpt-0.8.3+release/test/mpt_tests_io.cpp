
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/io/tests/tests_io.hpp"

#endif
