
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/format/tests/tests_format_message.hpp"
#include "mpt/format/tests/tests_format_simple.hpp"

#endif
