
#include "stdafx.h"

#ifdef ENABLE_TESTS

#include "mpt/string/tests/tests_string_buffer.hpp"
#include "mpt/string/tests/tests_string_utility.hpp"

#endif
