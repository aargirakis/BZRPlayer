//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resources.rc
//
#define IDI_ICON                       500
#define IDI_ICONSMALL                  501
