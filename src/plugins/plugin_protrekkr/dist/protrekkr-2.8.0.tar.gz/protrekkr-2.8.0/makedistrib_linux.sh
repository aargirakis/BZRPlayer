cd release/distrib/
zip -vr ptk_v2.8.0_linux.zip * -x@../../exclude_linux.lst
cd ..
cd ..

