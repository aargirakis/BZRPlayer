cd release/distrib/
zip -vr ptk_v2.8.0_freebsd.zip * -x@../../exclude_freebsd.lst
cd ..
cd ..

