cd release/distrib/
zip -vr ptk_v2.8.0_macosx_ia64.zip * -x@../../exclude_macosx_ia64.lst
cd ..
cd ..
