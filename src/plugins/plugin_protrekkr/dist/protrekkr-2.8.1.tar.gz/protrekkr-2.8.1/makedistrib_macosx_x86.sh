cd release/distrib/
zip -vr ptk_v2.8.1_macosx_x86.zip * -x@../../exclude_macosx_x86.lst
cd ..
cd ..
