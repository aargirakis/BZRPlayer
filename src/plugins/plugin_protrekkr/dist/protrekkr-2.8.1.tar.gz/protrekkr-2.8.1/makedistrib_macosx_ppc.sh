cd release/distrib/
zip -vr ptk_v2.8.1_macosx_ppc.zip * -x@../../exclude_macosx_ppc.lst
cd ..
cd ..
