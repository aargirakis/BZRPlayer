cd release/distrib/
zip -vr ptk_v2.8.1_netbsd_amd64.zip * -x@../../exclude_netbsd.lst
cd ..
cd ..

