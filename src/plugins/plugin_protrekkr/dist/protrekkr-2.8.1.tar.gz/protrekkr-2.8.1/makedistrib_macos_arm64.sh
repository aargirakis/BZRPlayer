cd release/distrib/
zip -vr ptk_v2.8.1_macos_arm64.zip * -x@../../exclude_macos_arm64.lst
cd ..
cd ..
