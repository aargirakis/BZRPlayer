cd release/distrib/
zip -vr ptk_v2.8.1_freebsd.zip * -x@../../exclude_freebsd.lst
cd ..
cd ..

