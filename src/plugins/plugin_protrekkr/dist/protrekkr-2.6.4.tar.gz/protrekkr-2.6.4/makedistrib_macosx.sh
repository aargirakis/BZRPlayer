cd release/distrib/
zip -vr ptk_v2.6.4_macosx.zip * -x@../../exclude_macosx.lst
cd ..
cd ..
