cd release/distrib/
tar --bzip2 -cvf ptk_v2.6.4_aros.tar.bz2 * -X../../exclude_linux.lst
cd ..
cd ..

