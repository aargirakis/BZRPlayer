cd release/distrib/
zip -vr ptk_v2.6.4_freebsd.zip * -x@../../exclude_linux.lst
cd ..
cd ..

