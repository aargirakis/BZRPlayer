#ifndef _VERSION_H_
#define _VERSION_H_

#define VERSION_ID	"20070206"
#define VERSION_TEXT1   "Nagasaki-Line"
#define VERSION_TEXT2   "Hizen-Hama"

#endif /*_VERSION_H_*/
