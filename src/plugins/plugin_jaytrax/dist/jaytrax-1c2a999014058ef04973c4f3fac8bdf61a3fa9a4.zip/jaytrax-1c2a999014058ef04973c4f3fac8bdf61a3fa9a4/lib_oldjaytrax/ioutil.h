enum loadErr {
    ERR_OK,
    ERR_MALLOC,
    ERR_BADSONG,
    ERR_FILEIO
};