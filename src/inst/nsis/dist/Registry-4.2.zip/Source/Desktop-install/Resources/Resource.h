//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Install.rc
//
#define IDI_ICON                        1001
#define IDD_PATH                        1002
#define IDC_BIGICON                     1101
#define IDC_PATHANSI                    1102
#define IDC_BROWSEANSI                  1103
#define IDC_PATHUNI                     1104
#define IDC_BROWSEUNI                   1105
#define IDC_STATIC                      -1


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
